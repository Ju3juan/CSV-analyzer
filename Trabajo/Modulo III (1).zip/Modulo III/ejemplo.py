import random

def generarNumeros(tope):
    listaNum=[random.randint(1,100) for z in range(tope)]
    return listaNum

def generarNum(tope):
    lista=[]
    for z in range(tope):
        num=random.randint(1,100)
        if not num in lista:
            lista.append(num)
    imprimir(lista)

def imprimir(mensaje):
    print(mensaje)

valor = int(input("Ingrese un número "))
print(f"Números generados {generarNumeros(valor)}")
#listaNum=[]
#for z in range(5):
#    listaNum.append(random.randint(1,100))
#print(listaNum)
