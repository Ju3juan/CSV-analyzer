class Suma:
    def __init__(self) :
        self.valorInicial=0
        self.valorFinal=0
    
    def asignar(self,valIni,valFin):
        self.valorInicial=valIni
        self.valorFinal=valFin
    
    def calcularSuma(self):
        return self.suma(self.valorInicial,self.valorFinal)
    
    def suma(self,valInicial,valFinal):
        if valInicial>=valFinal:
            return valInicial
        else:
            return valInicial+self.suma(valInicial+1,valFinal)


objSuma = Suma()
valIni= int(input("Ingrese el valor inicial "))
valFin=int(input("Ingrese el valor Final "))
objSuma.asignar(valIni,valFin)
print(f"La suma es {objSuma.calcularSuma()}")