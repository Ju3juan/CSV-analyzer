class Login:

    def __init__(self) :
        self.usuario=""
        self.password=""
        self.intentos=0
    
    def setUsuario(self,usuario):
        self.usuario=usuario
    
    def setPassword(self,password):
        self.password=password

    def comprobar(self):
        if self.usuario=="jchiru" and self.password=="12345":
            self.imprimir(f"Bienvenido a la Clase {self.usuario}")
            return False
        else:
            self.intentos+=1
            self.imprimir("Usuario o Password Incorrecto")
            return True
    
    def estado (self):
        if self.intentos==3:
            self.imprimir("Se le niega el acceso y su cuenta fue bloqueada")
        
    def imprimir(self,mensaje):
        print(mensaje)


obj=Login()
boleano=True
intentos=1
while intentos<=3 and boleano:
    usuario=input("Ingrese el usuario ")
    passw=input("Ingrse la contraseña ")
    obj.setUsuario(usuario)
    obj.setPassword(passw)
    boleano=obj.comprobar()
    print(boleano)
    intentos+=1
obj.estado()
