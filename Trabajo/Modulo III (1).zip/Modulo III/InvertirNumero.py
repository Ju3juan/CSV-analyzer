class InvertirNumero:

    def __init__(self)  :
        self.numero=0

    def setNumero(self,valNum):
        self.numero=valNum
    
    def llamadoRecursivo(self):
        return self.recusivoInvertir(self.numero,"")
    
    def recusivoInvertir(self,numOriginal,numFinal):
        if numOriginal>=1:
            numFinal=numFinal+str(numOriginal%10)
            numOriginal=int(numOriginal/10)
            return self.recusivoInvertir(numOriginal,numFinal)
        else:
            return numFinal