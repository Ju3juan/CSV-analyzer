class IncrementoSalarial:

    def __init__(self) :
        self.piezas=0
        self.salario=0.0

    def asignar(self,pie,sal):
        self.salario=sal
        self.piezas=pie
    
    def determinarSalario(self):
        porcentaje=0.0
        if self.piezas>=5 and self.piezas<=19:
            porcentaje=0.02
        elif self.piezas>=20 and self.piezas<=50:
            porcentaje=0.08
        elif self.piezas> 50:
            porcentaje=0.10
        return self.salario+self.salario*porcentaje   
     
objIncre = IncrementoSalarial()

for i in range(3):
    cantidad=int(input("Ingrese la cantidad de Piezas "))
    salario=float(input("Ingrese el Salario "))
    objIncre.asignar(cantidad,salario)
    print(f"El salario es {objIncre.determinarSalario()}")
