class PromedioGeneral:

    def __init__(self):
        self._estudiante={}
    
    def asignar(self,estu):
        self._estudiante=estu
    
    def promedio(self):
        return sum(self._estudiante.values())/ len(self._estudiante.values())
    
    def mayorAlPr(self):
        promEdades=self.promedio()
        for nombre,edad in self._estudiante.items():
            if edad>promEdades:
                self.imprimir(nombre)
    
    def imprimir(self,mensaje):
        print(mensaje)

objPromedio=PromedioGeneral()
estudiante={}
cantidad=int(input("Ingrese la cantidad de Estudiante "))
for z in range(cantidad):
    nombre=input("Ingrese el nombre del Estudiante ")
    edad=int(input("Ingrese la edad "))
    estudiante[nombre]=edad
objPromedio.asignar(estudiante)
objPromedio.mayorAlPr()