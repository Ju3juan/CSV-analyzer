class Numero:

    def __init__(self) :
        self.num=0

    def asignarVeriricar(self, valNum):
        self.num=valNum
        return self.validarNum()

    def validarNum(self):
        try:
            float(self.num)
            return False
        except:
            self.mensaje("Ingreso un texto, debe ser un número")
            return True
    
    def mensaje(self,msj):
        print(msj)