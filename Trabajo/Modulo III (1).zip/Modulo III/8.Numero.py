import Numero as validar
import InvertirNumero as recursivo

objValidar=validar.Numero()
objRecur=recursivo.InvertirNumero()
valNum=True
while valNum:
    num=input("Ingrese un número : ")
    valNum=objValidar.asignarVeriricar(num)
num=abs(int(num))
objRecur.setNumero(num)
print(f"{num} ----> {objRecur.llamadoRecursivo()}")