class Suma:
    def __init__(self) :
        self.valorInicial=0
        self.valorFinal=0
    
    def asignar(self,valIni,valFin):
        self.valorInicial=valIni
        self.valorFinal=valFin
    
    def suma(self):
        sumaNUm=0
        for z in range(self.valorInicial,self.valorFinal+1):
            sumaNUm+=z
        return sumaNUm


objSuma = Suma()
valIni= int(input("Ingrese el valor inicial "))
valFin=int(input("Ingrese el valor Final "))
objSuma.asignar(valIni,valFin)
print(f"La suma es {objSuma.suma()}")